from backend.database import db  # Adicionando "backend."
