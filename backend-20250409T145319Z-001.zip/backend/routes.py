from flask import Blueprint, request, jsonify
from backend.database import db  # Adicionando "backend."
from backend.models import Task  # Adicionando "backend."
